create procedure getInfo2(v_job nvarchar2)
as
e emp%rowtype;
cursor emp_cur is select * into e from emp where job = v_job;
begin
for p in emp_cur loop
dbms_output.put_line(p.job);
end loop;
end;
/

