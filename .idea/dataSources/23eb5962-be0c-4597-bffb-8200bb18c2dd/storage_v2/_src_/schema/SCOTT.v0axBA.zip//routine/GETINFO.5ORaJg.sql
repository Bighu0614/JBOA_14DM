create procedure getInfo
as
cursor emp_cur is select job from emp;
begin
for p in emp_cur loop
dbms_output.put_line(p.job);
end loop;
end;
/

